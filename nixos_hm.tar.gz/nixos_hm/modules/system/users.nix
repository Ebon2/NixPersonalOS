{ config, pkgs, ... }:

{
  users.users.angel = {
    isNormalUser = true;
    description  = "Angel Rojas";
    extraGroups  = [ "networkmanager" "wheel" "video" "audio" "docker" ];
    shell        = pkgs.fish;
    # Home Manager gestiona los dotfiles; no se necesita packages aquí
    # (úsalo solo para paquetes que dependan de privilegios del sistema)
  };

  # Genera la contraseña con: mkpasswd -m sha-512
  users.users.angel.hashedPassword = "$6$20XmGO57ulgBp3dn$.kS6q0LOJW1djfaQMntr4eMOJIiaTvZ9ZHzBuHF9UM3dYZk9IRhQOoTSCwdYkx.gKobUHcQ7yiUtWuhbBnJbj1";
}
