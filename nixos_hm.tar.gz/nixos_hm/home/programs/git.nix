{ ... }:

{
  programs.git = {
    enable    = true;
    userName  = "Angel Rojas";
    userEmail = "luis.mgcn@gmail.com"; # ← cambia esto

    extraConfig = {
      init.defaultBranch = "main";
      pull.rebase        = false;
      core.editor        = "nvim";
      diff.colorMoved    = "default";
    };

    # delta — diff más bonito (opcional)
    delta.enable = true;
  };
}
