function OpenUniversity --description="Ir a carpeta universidad"
    cd /home/angel/Escritorio/Carpeta_Personal/universidad $argv
end
